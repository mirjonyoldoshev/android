
export type Platform = "ios" | "macos"