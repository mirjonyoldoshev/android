export const GITHUB_RUN_NUMBER = process.env.GITHUB_RUN_NUMBER
  ? Number(process.env.GITHUB_RUN_NUMBER)
  : undefined
